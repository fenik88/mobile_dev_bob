//
//  AddCardView.swift
//  FlashWords
//

import SwiftUI

struct AddCardView: View {
    @EnvironmentObject private var store: CardStore
    @Environment(\.dismiss) private var dismiss

    @State private var word = ""
    @State private var translation = ""
    @State private var example = ""

    var isValid: Bool {
        !word.trimmingCharacters(in: .whitespaces).isEmpty &&
        !translation.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text(NSLocalizedString("section_word", comment: ""))) {
                    TextField(NSLocalizedString("field_word", comment: ""), text: $word)
                    TextField(NSLocalizedString("field_translation", comment: ""), text: $translation)
                }
                Section(header: Text(NSLocalizedString("section_example", comment: ""))) {
                    TextField(NSLocalizedString("field_example", comment: ""), text: $example, axis: .vertical)
                        .lineLimit(3...6)
                }
            }
            .navigationTitle(NSLocalizedString("add_card_title", comment: ""))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(NSLocalizedString("cancel", comment: "")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(NSLocalizedString("save", comment: "")) { save() }
                        .disabled(!isValid)
                }
            }
        }
    }

    private func save() {
        store.add(
            word: word.trimmingCharacters(in: .whitespaces),
            translation: translation.trimmingCharacters(in: .whitespaces),
            example: example.trimmingCharacters(in: .whitespaces)
        )
        dismiss()
    }
}
