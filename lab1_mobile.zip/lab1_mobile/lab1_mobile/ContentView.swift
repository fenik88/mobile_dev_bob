//
//  ContentView.swift
//  FlashWords
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: CardStore
    @State private var showingAdd = false
    @State private var searchText = ""

    var filtered: [WordCard] {
        if searchText.isEmpty { return store.cards }
        return store.cards.filter {
            $0.word.localizedCaseInsensitiveContains(searchText) ||
            $0.translation.localizedCaseInsensitiveContains(searchText)
        }
    }

    
    
    var body: some View {
        NavigationStack {
            Group {
                if store.cards.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "rectangle.stack.badge.plus")
                            .font(.system(size: 60))
                            .foregroundStyle(.secondary)
                        Text(NSLocalizedString("empty_state", comment: ""))
                            .font(.headline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(filtered) { card in
                            NavigationLink(destination: CardDetailView(card: card)) {
                                CardRowView(card: card)
                            }
                        }
                        .onDelete { offsets in
                            let toDelete = offsets.map { filtered[$0] }
                            toDelete.forEach { store.delete(card: $0) }
                        }
                    }
                    .searchable(text: $searchText, prompt: NSLocalizedString("search_placeholder", comment: ""))
                }
            }
            .navigationTitle("FlashWords")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showingAdd = true } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAdd) {
                AddCardView()
            }
        }
    }
}

struct CardRowView: View {
    @ObservedObject var card: WordCard

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(card.word)
                    .font(.headline)
                Text(card.translation)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if card.isLearned {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            }
        }
        .padding(.vertical, 2)
    }
}
#Preview {
    ContentView()
        .environmentObject(CardStore())
}
