//
//  lab1_mobileApp.swift
//  FlashWords
//

import SwiftUI

@main
struct lab1_mobileApp: App {
    @StateObject private var store = CardStore.shared
    @AppStorage("appTheme") private var appTheme: String = "system"

    var preferredColorScheme: ColorScheme? {
        switch appTheme {
        case "light": return .light
        case "dark":  return .dark
        default:      return nil
        }
    }

    var body: some Scene {
        WindowGroup {
            SplashView()
                .environmentObject(store)
                .preferredColorScheme(preferredColorScheme)
        }
    }
}
